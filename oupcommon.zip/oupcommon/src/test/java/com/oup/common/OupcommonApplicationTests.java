package com.oup.common;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OupcommonApplicationTests {

	@Test
	void contextLoads() {
	}

}
