package com.oup.common;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OupcommonApplication {

	public static void main(String[] args) {
		SpringApplication.run(OupcommonApplication.class, args);
	}

}
